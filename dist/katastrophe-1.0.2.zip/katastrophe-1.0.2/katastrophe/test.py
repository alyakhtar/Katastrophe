from tabulate import tabulate
import sys
import unicodedata

# print sys.stdout.encoding

a = [(1, '\xef\xbb\xbfThe Flash 2014 S02E23 HDTV x264-LOL[ettv]', u'244.26 MB', u'12276', u'858'), (2, '\xef\xbb\xbfThe Flash 2014 S02E22 HDTV x264-LOL[ettv]', u'274.26 MB', u'5467', u'333'), (3, '\xef\xbb\xbfThe Flash 2014 S02E21 HDTV x264-LOL[ettv]', u'249.61 MB', u'4017', u'219'), (4, '\xef\xbb\xbfThe Flash 2014 S02E20 HDTV x264-LOL[ettv]', u'235.12 MB', u'3137', u'260'), (5, '\xef\xbb\xbfThe Flash 2014 S02E19 HDTV x264-LOL[ettv]', u'209.37 MB', u'2406', u'123'), (6, '\xef\xbb\xbfThe Flash 2014 S02E18 HDTV x264-LOL[ettv]', u'218.62 MB', u'2130', u'81'), (7, '\xef\xbb\xbfThe Flash 2014 S02E17 HDTV x264-LOL[ettv]', u'251.74 MB', u'1644', u'101'), (8, '\xef\xbb\xbfThe Flash 2014 S02E23 720p HDTV X264-DIMENSION[rartv]', u'889.91 MB', u'1567', u'144'), (9, '\xef\xbb\xbfThe Flash 2014 S02E16 HDTV x264-LOL[ettv]', u'304.02 MB', u'1537', u'63'), (10, '\xef\xbb\xbfThe Flash (2014) S02E23 FASTSUB VOSTFR HDTV XviD-ZT avi', u'348.63 MB', u'1515', u'80'), (11, '\xef\xbb\xbfThe Flash 2014 S02E15 HDTV x264-LOL[ettv]', u'231.95 MB', u'1217', u'56'), (12, '\xef\xbb\xbfThe Flash 2014 S02E22 720p HDTV X264-DIMENSION[rartv]', u'852.52 MB', u'1044', u'73'), (13, '\xef\xbb\xbfThe Flash 2014 S02E14 HDTV x264-LOL[ettv]',
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       u'240.57 MB', u'1023', u'41'), (14, '\xef\xbb\xbfThe Flash 2014 S02E12 HDTV x264-LOL[ettv]', u'214.73 MB', u'971', u'36'), (15, '\xef\xbb\xbfThe Flash 2014 S02E23 720p HDTV X264-DIMENSION[ettv]', u'889.91 MB', u'926', u'60'), (16, '\xef\xbb\xbfThe Flash S02 Season 2 Complete 720p HDTV x265 AAC E-Subs [GWC]', u'3.88 GB', u'484', u'783'), (17, '\xef\xbb\xbfThe Flash 2014 S02E10 HDTV x264-LOL[ettv]', u'213.95 MB', u'844', u'51'), (18, '\xef\xbb\xbfThe Flash 2014 S02E22 FASTSUB VOSTFR HDTV XviD-ZT avi', u'355.99 MB', u'804', u'23'), (19, '\xef\xbb\xbfThe Flash 2014 S02E08 HDTV x264-LOL[ettv]', u'238.29 MB', u'781', u'42'), (20, '\xef\xbb\xbfThe Flash 2014 S02E23 HDTV XviD-FUM[ettv]', u'348.29 MB', u'780', u'38'), (21, '\xef\xbb\xbfThe Flash 2014 S02E21 720p HDTV X264-DIMENSION[rartv]', u'690.77 MB', u'673', u'41'), (22, '\xef\xbb\xbfThe Flash 2014 S02E13 HDTV x264-LOL[ettv]', u'245.68 MB', u'667', u'41'), (23, '\xef\xbb\xbfThe Flash 2014 S02E23 1080p HDTV X264-DIMENSION[rartv]', u'2.67 GB', u'639', u'69'), (24, '\xef\xbb\xbfThe Flash 2014 S02E11 HDTV x264-LOL[rartv]', u'219.59 MB', u'622', u'41'), (25, '\xef\xbb\xbfThe Flash 2014 S02E23 HDTV x264-LOL[rartv]', u'244.26 MB', u'625', u'22')]

# c = '(\xef\xbd\xa1\xef\xbd\xa5\xcf\x89\xef\xbd\xa5\xef\xbd\xa1\xef\xbe\x89'
# d = '(\xef\xbd\xa1\xef\xbd\xa5\xcf\x89\xef\xbd\xa5\xef\xbd\xa1\xef\xbe\x89'.decode('utf-8') 
for i in a:
	b = i[1]
	new = ''.join([i if ord(i) < 128 else '' for i in b])
	# print [w.replace(a[1], new) for w in a[1]]
	print new

print a

# 	splt = a.split("\\")
# 	print splt
# print tabulate(a)
# print type(c)


# print c
# print d

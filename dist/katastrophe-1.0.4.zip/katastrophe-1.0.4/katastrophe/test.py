from tabulate import tabulate
import sys
import unicodedata
import os
import sys

import subprocess
cmd = 'WMIC PROCESS get Caption'
a = []
proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
for line in proc.stdout:
    a.append(line.strip())

d = 'utorrent'
b = 'bittorrent'
c = 'utorrentie.exe'

# print a in c
for i in a :
	# print i
	if d in i.lower() :
		print d
	elif b in i.lower():
		print b

# print a


# import subprocess
# cmd = 'wmic process where "name=\'uTorrent.exe\'" get ExecutablePath'
# proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
# a = proc.stdout.read().strip()
# if a == "":
	# print 'heyy'
# pr
# print a.split('ExecutablePath')[1].strip()